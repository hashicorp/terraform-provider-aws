const validRequestTypes = ["Create", "Update", "Delete"]

exports.handler = async (event) => {
    console.log("EVENT: \n" + JSON.stringify(event, null, 2))
    let requestType = event.RequestType
    let valid = validRequestTypes.includes(requestType)
    let status = "SUCCESS"
    let reason = "N/A"
    let data = {}
    if (valid) {
        console.log("Performing operation: " + requestType)
        for (const [key, value] of Object.entries(event.ResourceProperties)) {
            data[key] = String(value)
        }
    }
    else {
        status = "FAILURE"
        reason = "Invalid request type."
    }

    const response = {
        Status: status,
        Reason: reason,
        Data: data,
    }

    return response
}