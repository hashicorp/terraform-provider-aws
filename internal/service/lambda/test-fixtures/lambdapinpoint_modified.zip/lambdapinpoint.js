var http = require('http')

exports.handler = function(event, context, callback) {
    var response = {
        body: "ok_modified",
        statusCode: 200
    };

    callback(null, response);
}
