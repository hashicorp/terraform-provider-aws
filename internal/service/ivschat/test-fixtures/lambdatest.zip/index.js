exports.handler = async function ({Content}) {
    return { ReviewResult: "ALLOW", Content };
}
