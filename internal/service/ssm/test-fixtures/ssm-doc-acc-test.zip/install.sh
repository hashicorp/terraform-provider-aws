!/bin/bash

echo 'Installing ExamplePackage on Amazon Linux...'

# Add command to call installer.  For example "yum install ./ExamplePackage.rpm"