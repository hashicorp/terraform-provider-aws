---
name: test-skill-bundle
description: A bundled test skill with references.
---

# Test Skill Bundle

This skill includes reference material.
