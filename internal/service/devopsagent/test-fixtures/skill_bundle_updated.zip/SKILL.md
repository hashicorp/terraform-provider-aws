---
name: test-skill-bundle-updated
description: An updated bundled test skill with references.
---

# Updated Test Skill Bundle

This skill has been updated with new reference material.
