# Updated Reference Guide

Revised reference material for the skill.
