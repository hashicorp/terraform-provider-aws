import { createServer } from 'http';
import { readFileSync } from 'fs';

const server = createServer((req, res) => {
  if (req.url === '/hello-world') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      message: 'Hello from the Lambda Web function API',
      timestamp: new Date().toISOString(),
      status: 'success',
    }));
    return;
  }

  try {
    const html = readFileSync('index.html', 'utf8');
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(html);
  } catch (error) {
    res.writeHead(404);
    res.end('Not Found');
  }
});

server.listen(3000, '0.0.0.0', () => console.log('Server running on port 3000'));

process.on('SIGTERM', () => server.close(() => process.exit(0)));
