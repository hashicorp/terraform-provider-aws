
import { SecretsManagerClient, DescribeSecretCommand, PutSecretValueCommand, UpdateSecretVersionStageCommand  } from "@aws-sdk/client-secrets-manager";

const client = new SecretsManagerClient({ region: "us-east-1" });

  export async function handler (event, context) {
    const arn = event.SecretId
    const step = event.Step
    const token = event.ClientRequestToken

    console.log(event)

    switch(step) {
      case "createSecret":
        updateSecret(client, arn, token)
        break
      case "setSecret":
      case "testSecret":
        return
      case "finishSecret":
        await finishSecret(client, arn, token)
        break
      default:
        throw new Error(`Invalid step: ${step}`)
    }
  }

  async function updateSecret(client, arn, token) {
    const input = { // PutSecretValueRequest
      SecretId: arn, // required
      ClientRequestToken: token,
      SecretString: JSON.stringify({key: "value"}),
      VersionStages: [ // SecretVersionStagesType
        "AWSPENDING",
      ],
    };

    const command = new PutSecretValueCommand(input)
    await client.send(command)
  }

  async function describeSecret(client, arn) {
    const input = { // GetSecretValueRequest
      SecretId: arn, // required
    };
    
    const command = new DescribeSecretCommand(input);
    return await client.send(command);
  }

  async function finishSecret(client, arn, token) {
    const currentVersionStage = "AWSCURRENT"
    const secret = await describeSecret(client, arn)
    
    let currentVersion = null;

    for(const [version, stages] of Object.entries(secret.VersionIdsToStages)) {
      if(stages.includes(currentVersionStage)) {
        if(version === token) {
          console.log(`finishSecret: Version %s already marked as AWSCURRENT for ${version}, ${arn}`)
          return
        }

        currentVersion = version 
        break    
      }
    }

  const input = { // UpdateSecretVersionStageRequest
    SecretId: arn, // required
    VersionStage: currentVersionStage, // required
    MoveToVersionId: token
  };

  if(currentVersion) {
    input.RemoveFromVersionId = currentVersion
  }

  const command = new UpdateSecretVersionStageCommand(input);
  await client.send(command)
  }