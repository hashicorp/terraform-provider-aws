var http = require('http')

exports.handler = function(event, context, callback) {
    var response = {
        body: "ok",
        statusCode: 200
    };

    callback(null, response);
}
